// Load environment variables
require("dotenv").config();

// Start server
const startServer = require("./server");
startServer();